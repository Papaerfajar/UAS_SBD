	<style>
	footer {
	clear:both;
	background-color:#1d1d1d;
	padding:8px;
	color:#eee;
	}
	</style>
	<footer>
		<p>&copy; 2022 - Fajar Amarullah 312010128</p>
	</footer>