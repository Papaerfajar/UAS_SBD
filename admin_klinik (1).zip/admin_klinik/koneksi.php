<?php
$host="localhost";
$user="adminklinik";
$password="312010128";
$db="klinik_312010128";

$con = mysqli_connect($host,$user,$password,$db);
if (!$con){
	  die("Koneksi gagal:".mysqli_connect_error());
}
?>